<?php

define('_VERSION','5_6_0_20160825_UTF8');
define('_VERNUM','5.6.0.20160825');
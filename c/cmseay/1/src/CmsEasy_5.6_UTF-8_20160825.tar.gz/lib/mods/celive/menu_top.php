<?php

return array(
'客服'=>url::create('index/index/mod/celive'),
);
<?php

if (!defined('ROOT')) exit('Can\'t Access !');
class table_comment extends table_mode {
}
<?php

class pay_exchange extends table {

}
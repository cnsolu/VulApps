<?php

if (!defined('ROOT')) exit('Can\'t Access !');
class table_pay  extends table_mode {

}
<?php


class weixinreply  extends table {

    public $name='weixinreply';

} 
<?php

if (!defined('ROOT')) exit('Can\'t Access !');
class table_guestbook extends table_mode {
}
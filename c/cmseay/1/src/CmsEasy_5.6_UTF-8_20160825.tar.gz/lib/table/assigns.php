<?php

class assigns extends table {

}
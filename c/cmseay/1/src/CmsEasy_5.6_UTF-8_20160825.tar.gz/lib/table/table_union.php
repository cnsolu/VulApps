<?php

if (!defined('ROOT')) exit('Can\'t Access !');
class table_union  extends table_mode {
}
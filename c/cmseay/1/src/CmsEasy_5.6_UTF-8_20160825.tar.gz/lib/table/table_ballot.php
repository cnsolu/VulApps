<?php

if (!defined('ROOT')) exit('Can\'t Access !');
class table_ballot extends table_mode {
    function add_before(act $act) {
    }
}
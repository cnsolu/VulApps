<?php


if (!defined('ROOT')) exit('Can\'t Access !');
class table_invite extends table_mode {
    function save_before() {
        //
    }
    function delete_before() {
        //
    }
    function mail_before() {
        //
    }
}
<?php

class activity extends table {
    
}
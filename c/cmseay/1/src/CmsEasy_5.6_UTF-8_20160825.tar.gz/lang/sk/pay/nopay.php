<?php


global $_LANG;

$_LANG['nopay'] = '不支付，仅下订单';
$_LANG['nopay_desc'] = '客户暂不支付，仅仅下订单，网站主主动联系客户。';

?>
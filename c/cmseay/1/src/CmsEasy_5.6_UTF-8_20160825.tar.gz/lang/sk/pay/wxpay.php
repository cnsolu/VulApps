<?php
global $_LANG;

$_LANG['wxpay'] = '微信支付';
$_LANG['APPID'] = 'APPID';
$_LANG['MCHID'] = 'MCHID';
$_LANG['KEY'] = 'KEY';
$_LANG['APPSECRET'] = 'APPSECRET';
<?php
global $_LANG;

$_LANG['wxscanpay'] = '微信扫码支付';
$_LANG['APPID'] = 'APPID';
$_LANG['MCHID'] = 'MCHID';
$_LANG['KEY'] = 'KEY';
$_LANG['APPSECRET'] = 'APPSECRET';
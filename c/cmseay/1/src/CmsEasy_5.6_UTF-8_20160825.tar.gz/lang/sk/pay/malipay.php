<?php
global $_LANG;

$_LANG['malipay'] = '手机支付宝';
$_LANG['alipay_partner'] = '合作者身份ID';
$_LANG['alipay_private'] = '商户私钥';
$_LANG['alipay_public'] = '支付宝公钥';
$_LANG['pay_button'] = '使用手机支付宝支付';
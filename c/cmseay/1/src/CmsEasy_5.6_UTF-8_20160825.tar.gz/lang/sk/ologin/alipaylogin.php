<?php

global $_LANG;

$_LANG['alipaylogin'] = '支付宝登录';
$_LANG['alipaylogin_desc'] = '支付宝用户整合登录';
$_LANG['alipaylogin_id'] = '交易安全校验码';
$_LANG['alipaylogin_key'] = '合作者身份ID';
?>